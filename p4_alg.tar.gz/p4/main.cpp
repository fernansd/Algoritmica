#include <iostream>
#include <vector>

#include "Moneda.hpp"
#include "SistemaMonetario.hpp"
#include "funciones.hpp"

int main () {
	using namespace std;

	SistemaMonetario s {1,2,5, // Monedas de 1, 2 y 5 centimos
						10,20,50,
						100,200,500, // Monedas de 1, 2 y 5 euros
						1000,2000,5000,
						10000,20000,50000}; // Billetes de 100, 200 y 500 euros

	int dinero;
	cout << "Cantidad: ";
	cin >> dinero;

	Cambio cambio = obtenerCambio(dinero, s);

	for (auto& elem : cambio) {
		cout << elem.moneda << " : " << elem.cantidad << endl;
	}

	

	return 0;
}