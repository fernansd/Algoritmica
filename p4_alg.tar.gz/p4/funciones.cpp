#include "funciones.hpp"

#include <iostream>

Cambio obtenerCambio(int dinero, SistemaMonetario& s) {
	std::vector<Cantidad> v;

	for (auto it = s.rbegin(); it != s.rend(); it++) {
		Cantidad c(it->getValor());

		while (c.moneda <= dinero) {
			c.cantidad++;
			dinero -= c.moneda.getValor();
		}

		if (c.cantidad > 0) {
			v.push_back(c);
		}

		if (dinero <= 0)
			break;

	}

	/*if (dinero != 0) {
		return Cambio();
	}*/

	return v;
}