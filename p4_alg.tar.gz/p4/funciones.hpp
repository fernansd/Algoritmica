#ifndef FUNCIONES_HPP
#define FUNCIONES_HPP

#include <vector>

#include "Moneda.hpp"
#include "SistemaMonetario.hpp"

struct Cantidad {
	Moneda moneda;
	int cantidad = 0;

	Cantidad(int val)
		: moneda(val) { }
};

typedef std::vector<Cantidad> Cambio;

Cambio obtenerCambio(int cantidad, SistemaMonetario& s);
#endif