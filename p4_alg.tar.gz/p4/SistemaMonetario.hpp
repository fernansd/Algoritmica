#ifndef CLASE_SISTEMA_MONETARIO_HPP
#define CLASE_SISTEMA_MONETARIO_HPP

#include <cassert>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>

#include "Moneda.hpp"

struct Cantidad;

class SistemaMonetario : public std::set<Moneda> {
public:
	SistemaMonetario() { }
	SistemaMonetario(std::vector<Moneda>& v)
	{
		this->insert(v.begin(), v.end());
	}

	SistemaMonetario(std::initializer_list<Moneda> list)
		: std::set<Moneda>(list) { }

	// Inserta una moneda al sistema
	void push(const Moneda& m) {
		this->insert(m);
	}

	// Quita una moneda del sistema y la devuelve
	Moneda pop(int valor) {
		Moneda m(valor);
		this->erase(m);
		return m;
	}

	// Comprueba si existe una moneda determinada
	bool exists(const Moneda& m) const {
		// Cuando find devuelve end, es que no ha encontrado el elemento
		return !(this->find(m) == this->end());
	}

	bool exists(int valor) const {
		Moneda m(valor);
		return this->exists(m);
	}

	friend std::ostream& operator<<(std::ostream& stream, const SistemaMonetario& s)
	{
		for (auto it = s.begin(); it != s.end(); it++) {
			stream << *it << " ";
		}

		return stream;
	}

	friend std::vector<Cantidad> obtenerCambio(int cantidad, SistemaMonetario& s);

private:
	int primer_billete = 0;
};
#endif